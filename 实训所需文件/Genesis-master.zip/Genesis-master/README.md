<h1 align="center">Genesis- 开发者社区</h1>
<h2 align="center"> 基于Spring+Spring MVC+Mybatis(Maven方式构建)</h2>

<p align="center">
 <a href="https://travis-ci.org/withstars/Genesis"><img src="https://travis-ci.org/withstars/Genesis.svg?branch=master" alt="travis-ci"></a>
 <a href="https://github.com/withstars/Genesis"><img src="https://img.shields.io/hexpm/l/plug.svg" alt="license"></a>
</p>
<img src="https://raw.githubusercontent.com/withstars/Genesis/master/preview/1.PNG">
<img src="https://raw.githubusercontent.com/withstars/Genesis/master/preview/2.PNG"></br>

## 说明
1. 如果使用该项目出现问题，请联系我 withstars@126.com
2. 如果该项目对您有帮助,请star鼓励我

## 如何使用
```aidl
$ git clone https://github.com/withstars/Genesis

$ cd Genesis

$ mvn clean compile

$ mvn clean package

$ mvn clean install

$ mvn jetty:run
 
 http://localhost:8080
```
## LICENSE
`Apache 2.0`
