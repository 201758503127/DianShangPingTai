package cn.techaction.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.techaction.common.SverResponse;
import cn.techaction.dao.TestDao;
import cn.techaction.pojo.User;


public interface TestService {
	//�����û�
	public SverResponse<List<User>> findAllUser();
	
}
