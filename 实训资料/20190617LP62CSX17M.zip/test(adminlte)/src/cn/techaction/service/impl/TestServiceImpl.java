package cn.techaction.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.techaction.common.SverResponse;
import cn.techaction.dao.TestDao;
import cn.techaction.pojo.User;
import cn.techaction.service.TestService;

@Service
public class TestServiceImpl implements TestService {
	@Autowired
	private TestDao testDao;

	@Override
	public SverResponse<List<User>> findAllUser() {
		List<User> findUser = testDao.findUser();
		return SverResponse.createRespBySuccess(findUser);
	}
}
