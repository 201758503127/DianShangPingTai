package cn.techaction.dao;

import java.util.List;

import cn.techaction.pojo.User;

public interface TestDao {
	public List<User> findUser();

}
