package cn.techaction.dao.impl;

import java.sql.SQLException;
import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.stereotype.Repository;

import cn.techaction.common.SverResponse;
import cn.techaction.dao.TestDao;
import cn.techaction.pojo.User;
@Repository
public class TestDaoimpl implements TestDao {

	@Resource
	private QueryRunner queryRunner;
	
	@Override
	public List<User> findUser() {
		String sql = "select * from user";
		try {
			return queryRunner.query(sql, new BeanListHandler<User>(User.class));
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
