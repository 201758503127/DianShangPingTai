package cn.techaction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.techaction.common.SverResponse;
import cn.techaction.pojo.User;
import cn.techaction.service.TestService;
@Controller
@RequestMapping("/user")
public class TestController {
	@Autowired
	private TestService testService;
	
	@RequestMapping("/finduser.do")
	@ResponseBody
	public SverResponse<List<User>> getUser() {
		return testService.findAllUser();	

	}


}
